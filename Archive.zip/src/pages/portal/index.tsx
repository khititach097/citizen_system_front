
import LayoutComponent from '@/components/layout/LayoutComponent'
import React from 'react'

const index = () => {
  return (
    <LayoutComponent>
      indexxxxx
    </LayoutComponent>
  )
}

export default index